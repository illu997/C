#ifndef INCLUDE_H

#define INCLUDE_H

double mittelwert(int *feld, int *groesse);
int groessteZahl(int *feld, int *groesse);
void sortieren(int *feld, int *groesse);
void absolut(int *feld, int *feld2, int *groesse);

#endif