#ifndef INCLUDE_H

#define INCLUDE_H

int equal(char x[], char y[]);

#endif